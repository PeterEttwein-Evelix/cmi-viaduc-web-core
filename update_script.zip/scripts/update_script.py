import os
import concurrent.futures
import logging
import json
import argparse
import time
import requests
from tqdm import tqdm


# Setup basic logging
logging.basicConfig(
    filename="update_script.log",
    level=logging.INFO,
    format="%(asctime)s:%(levelname)s:%(message)s",
)


def init_parser():
    """
    Setup and configuration of the CLI arguments
    """
    parser = argparse.ArgumentParser(description="Modify JSON files recursively.")
    parser.add_argument(
        "directory", type=str, help="Directory containing JSON files to process."
    )
    parser.add_argument(
        "--resume-file",
        type=str,
        default="resume.txt",
        help="File used to store the last processed file's name for resuming.",
    )
    parser.add_argument(
        "--search-base-url",
        required=True,
        type=str,
        help="Base URL for search service.",
    )
    parser.add_argument(
        "--prefix-identifier",
        required=True,
        type=str,
        help="Prefix to remove from URL to extract source.",
    )
    parser.add_argument(
        "--simulate",
        action="store_true",
        help="Simulate the modification without writing to files.",
    )
    parser.add_argument(
        "--solr",
        required=True,
        type=str,
        help="Solr API endpoint (e.g. http://localhost:8983/solr/iiif/)",
    )
    parser.add_argument(
        "--query-chunksize",
        help="The number of queries to send to solr at once. If 0, all queries will be sent at once.",
        type=int,
        default=100,
    )
    return parser


parser = init_parser()  # initialise the parser
args = parser.parse_args()  # parse the args


def scan_dir(dir_path):
    """Generator function to recursively scan a directory and yield paths to json files.
    Args:
        dir_path (str): The directory path to scan.
    Yields:
        str: The path to a JSON file.
    """
    try:
        with os.scandir(dir_path) as entries:
            for entry in entries:
                if entry.is_dir():
                    yield from scan_dir(entry.path)  # Recurse into subdirectory
                elif entry.is_file() and entry.name.endswith(".json"):
                    yield entry.path
    except PermissionError as e:
        logging.error(f"Permission denied: {e}")
    except OSError as e:
        logging.error(f"OS error: {e}")


def find_json_files(directory):
    """Recursively find all JSON files in the specified directory using os.scandir and multithreading for better performance with error handling.
    Args:
        directory (str): The directory to scan for JSON files.
    Returns:
        list: A list of paths to JSON files.
    """
    results = []
    with concurrent.futures.ThreadPoolExecutor() as executor:
        futures = []
        try:
            with os.scandir(directory) as entries:
                for entry in entries:
                    if (
                        entry.is_dir()
                    ):  # Ensure only directories are submitted for scanning
                        futures.append(executor.submit(list, scan_dir(entry.path)))
        except OSError as e:
            logging.error(f"OS error when scanning directory {directory}: {e}")

        for future in concurrent.futures.as_completed(futures):
            try:
                results.extend(future.result())
            except Exception as e:  # Catches any exceptions raised in worker threads
                logging.error(f"Error processing a directory: {e}")
    return results


def is_collection_manifest(data):
    """Check if the JSON data has a 'type' property with the value 'Collection'.
    Args:
        data (dict): The JSON data to check.
    Returns:
        bool: True if the data is a collection manifest, False otherwise.
    """
    try:
        return data.get("type") == "Collection"
    except KeyError:
        logging.error(f"Missing 'type' property in JSON data: {data}")
        return False


def is_resource_manifest(data):
    """Check if the JSON data has a 'type' property with the value 'Manifest'.
    Args:
        data (dict): The JSON data to check.
    Returns:
        bool: True if the data is a resource manifest, False otherwise.
    """
    try:
        return data.get("type") == "Manifest"
    except KeyError:
        logging.error(f"Missing 'type' property in JSON data: {data}")
        return False


import re

def extract_source(url):
    """
    Extract source from the given URL by removing the prefix and last segment,
    and normalizing double slashes in the path part of the URL.
    Args:
        url (str): The URL to extract the source from.
    Returns:
        str: The extracted source.
    """
    try:
        if not isinstance(url, str) or not isinstance(args.prefix_identifier, str):
            raise ValueError("Both 'url' and 'prefix_identifier' must be strings.")

        if not url.startswith(args.prefix_identifier):
            raise ValueError(
                f"URL {url} does not start with the required prefix: {args.prefix_identifier}"
            )

        # Remove the specified prefix
        url = url[len(args.prefix_identifier):]

        # Normalize double slashes in the URL path, excluding the protocol part
        protocol, sep, path = url.partition('://')
        if sep:  # Check if a protocol separator was found
            normalized_path = re.sub(r'(?<!:)/{2,}', '/', path)  # Avoid changing "://" to ":/"
            url = f"{protocol}{sep}{normalized_path}"
        else:
            url = re.sub(r'/+', '/', url)  # Normalize without protocol part

        # Remove the last segment from the URL and replace slashes with hyphens
        url = url.rsplit('/', 1)[0]
        source = url.replace('/', '-')

        if not source:
            raise ValueError("Source extracted is empty after processing.")

        return source

    except ValueError as ve:
        logging.error(f"Value error during source extraction: {ve}")
    except Exception as e:
        logging.error(f"Unexpected error extracting source from URL: {e}")
    return None


def add_search_service_to_collection_manifest(file_path, data):
    """Modify the JSON file by setting the 'id' in the new properties based on existing data.

    Args:
        file_path (str): Path to the JSON file to be modified.
        data (dict): Dictionary containing existing data from which the ID is derived.
        simulate (bool): Flag to simulate changes without actually writing to the file.
        search_base_url (str): Base URL to be appended to the extracted ID for the new search service.
        prefix_identifier (str): Identifier prefix to extract the relevant part of the ID.

    Returns:
        bool: True if the file was successfully modified, False otherwise.
    """
    try:
        identifier = data.get("id") or data.get("@id")

        if not identifier:
            raise KeyError("'id' key is missing in the data provided.")

        collection_id = extract_source(identifier)
        service_id = f"{args.search_base_url}{collection_id}"

        if args.simulate:
            logging.info(
                f"Would modify {file_path} with new search service ID: {service_id}"
            )
        else:
            data["service"] = {"id": service_id, "type": "SearchService2"}
            with open(file_path, "w", encoding="utf-8") as file:
                json.dump(data, file, indent=4)
                logging.info(
                    f"Successfully modified {file_path} with new search service ID."
                )

        return True

    except KeyError as ke:
        logging.error(f"Key error while processing {file_path}: {ke}")
    except FileNotFoundError:
        logging.error(f"File not found: {file_path}")
    except json.JSONDecodeError:
        logging.error(f"Invalid JSON in file: {file_path}")
    except Exception as e:
        logging.error(f"Unexpected error processing {file_path}: {e}")

    return False


def generate_solr_update_query(data):
    """
    Generate a SOLR update query for adding search service to collection manifest.
    Returns:
    dict: A SOLR update query
    """
    identifier = data.get("id") or data.get("@id")
    if not identifier:
        logging.error(f"Manifest ID not found in data: {data}")
        return None
    
    source = extract_source(identifier)
    document_ids = solr_fetch_document_ids(source)
    label = get_localized_value(data.get("label"))
    return [{
        "id": doc_id,
        "manifest_path": {"set": data.get("id")},
        "manifest_label": {"set": label[0] or ""}
    } for doc_id in document_ids]
    

def solr_fetch_document_ids(source):
    """
    Fetch existing SOLR document IDs based on the source field.
    Args:
        source (str): The source string extracted from the identifier URL.
    Returns:
        list: A list of document IDs.
    """
    query_url = f"{args.solr}/select?q=source:{source}&fl=id&rows=10000000&wt=json"
    try:
        response = requests.get(query_url)
        response_data = response.json()
        document_ids = [doc['id'] for doc in response_data['response']['docs']]
        return document_ids
    except Exception as e:
        logging.error(f"Failed to fetch document IDs from SOLR: {e}")
        return []

def solr_exec_update(query, current_chunk):
    """
    Execute SOLR update based on given query.
    Parameters:
    query (dict): A solr update query
    current_chunk (int): The current chunk number

    Returns:
    dict: The JSON response from SOLR
    """
    if args.simulate:
        logging.info("solr_update_query: %s" % str(query))
        return True
    else:
        logging.info("solr_update_query: %s" % str(query))
        r = requests.post(f"{args.solr}/update/?commit=true", json=query)
        time.sleep(1)
        logging.info(f"solr_update_response: {r.text}")
        return r.json()


def get_localized_value(label):
    """Returns the localized value of the iiif label, by prioritizing the 'en' language."""
    if not label:
        logging.warning(f"Label is empty. {label}")
        return ""

    if "en" in label:
        return label["en"]
    if "none" in label:
        return label["none"]

    logging.warning(f"Localized value not found for label: {label}")
    return ""


def process_files(directory):
    """Process all JSON files in a directory, with optional simulation and resuming.

    Args:
        directory (str): Directory containing JSON files to process.
        simulate (bool): Whether to simulate changes without actually writing to files.
        search_base_url (str): Base URL to be used for search service modifications.
        prefix_identifier (str): Prefix used to identify and process collection IDs.
        resume_file (str): File used to store the last processed file's name for resuming.

    Returns:
        None
    """
    try:
        all_files = list(find_json_files(directory))
        start_index = 0
        collection_count = 0
        manifest_count = 0
        queries = []

        if args.simulate:
            print(
                "!!! Simulation mode enabled. No changes will be written to files. Check the log for info output !!! \n"
            )

        if args.resume_file:
            try:
                with open(args.resume_file, "r") as file:
                    last_processed = file.read().strip()
                    start_index = (
                        all_files.index(last_processed) + 1
                        if last_processed in all_files
                        else 0
                    )
            except FileNotFoundError:
                logging.info(f"Resume file not existing: {args.resume_file}")

        progress = tqdm(
            all_files[start_index:], initial=start_index, total=len(all_files)
        )
        for file_path in progress:
            try:
                with open(file_path, "r", encoding="utf-8") as f:
                    data = json.load(f)
                if is_collection_manifest(data):
                    success = add_search_service_to_collection_manifest(file_path, data)
                    if success:
                        collection_count += 1
                if is_resource_manifest(data):
                    new_queries = generate_solr_update_query(data)
                    if new_queries:
                        queries.extend(new_queries)
                        if len(queries) >= args.query_chunksize:
                            solr_exec_update(queries, len(queries))
                            queries = []
                    manifest_count += 1
            except json.JSONDecodeError:
                logging.error(f"Invalid JSON in file: {file_path}")
            except FileNotFoundError:
                logging.error(f"File not found: {file_path}")
            except Exception as e:
                logging.error(f"Unexpected error processing file {file_path}: {e}")

        print(f"Processed {collection_count} collection manifest(s).")
        print(f"Processed {manifest_count} resource manifest(s).")
    except Exception as e:
        logging.critical(f"Failed to process files in directory {directory}: {e}")


if __name__ == "__main__":
    process_files(args.directory)
