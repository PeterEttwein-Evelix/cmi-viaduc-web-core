# Schritte zur Ausführung der Python-Skripte

## Vorbereitung

Bevor das Skript ausgeführt werden kann, müssen die folgenden Schritte durchgeführt werden:

### Solr-Core duplizieren

Da die Ausführung des Skripts eine gewisse Zeit in Anspruch nimmt, wird empfohlen, einen zweiten Solr-Core anzulegen, um die Daten zu indizieren. Dieser Core kann dann später mit dem bestehenden Core "geswapped" werden.

Dies hat den Vorteil, dass der bestehende Core weiterhin für Suchanfragen zur Verfügung steht, während der neue Core die Daten indiziert. Zudem kann der neue Core vorgängig getestet werden. Sollte bei der Inbetriebnahme des neuen Cores ein Problem auftreten, kann zudem wieder auf den alten Core zurückgewechselt werden.

#### Schritte zum Duplizieren des Cores

1. **Solr-Server stoppen**: Bevor Änderungen vorgenommen werden, sollte der Solr-Server gestoppt werden, um Dateninkonsistenzen zu vermeiden.
   
Dazu nutzen wir den Windows Server Manager, indem wir unter "Local Server" -> "Services" den Solr-Service suchen und via Kontextmenü stoppen.

![](./img/stop_solr_service.png)

2. **Core-Verzeichnis kopieren**: Das Verzeichnis des bestehenden Cores wird in ein neues Verzeichnis auf derselben Ebene kopiert. Beispiel:
   ```sh
    # Unix/Linux (Bash)
    cp -r /path/to/solr/server/solr/iiif /path/to/solr/server/solr/iiif2

    # Windows PowerShell on DEV-Server
    Copy-Item -Recurse -Path "E:\localdata\IIIF\solr\data\iiif" -Destination "E:\localdata\IIIF\solr\data\iiif2"
   ```

3. **Core-Konfigurationsdatei anpassen**: Die Datei `core.properties` im neuen Core-Verzeichnis wird bearbeitet, um den Namen des neuen Cores eindeutig zu machen.
   ```properties
   name=iiif2
   ```

4. **Solr-Server starten**:
   Da die Änderungen am Core abgeschlossen sind, kann der Solr-Server wieder gestartet werden.

![](./img/start_solr_service.png)

Nachdem diese Schritte ausgeführt wurden, sollte der neue Core eine exakte Kopie des ursprünglichen Cores sein. Dessen Index kann nun mit den neuen Daten gefüllt werden.

Wenn der neue Core erfolgreich getestet wurde, kann er später mit dem bestehenden Core "geswapped" werden.


### Solr-Schema erweitern

Folgende Felder werden dem Schema des **neuen** Cores hinzugefügt:
```xml
<!-- Schema-File auf DEV: E:\localdata\IIIF\solr\data\iiif2\conf\managed-schema.xml -->
<field name="manifest_label" multiValued="false" type="text_general"/>
<field name="manifest_path" multiValued="false" type="text_general"/>
```

Damit die Änderungen am Schema wirksam werden, muss der Solr-Server neu gestartet werden.

![](./img/restart_solr_service.png)

## Ausführung des Skripts

### Vorrequisiten

- Python 3.9 ist auf dem System installiert.
- Die Manifests sind lokal auf dem System vorhanden und der ausführende Benutzer hat Schreibzugriff auf die Dateien.

### Installation

**!!! Wichtig: [Vorrequisiten](#vorrequisiten) beachten !!!**

Um das Skript auf einem System ohne Internetverbindung auszuführen, müssen die folgenden Schritte durchgeführt werden:

1. Gelieferte Archiv-Datei `update_script.zip` entpacken.
2. In das entpackte Verzeichnis `update_script` wechseln.
3. Dependencies mit dem folgenden Befehl installieren:

```sh
# Info: Das --user Flag installiert die Dependencies lokal im Benutzerverzeichnis. Dadurch wird kein Administratorzugriff benötigt.
python -m pip install --user --no-index --find-links ./lib --no-deps -r requirements.txt
```

### Ausführung

Der Befehl bezieht alle Dependencies aus dem Verzeichnis `lib` und installiert sie lokal, ohne dafür das offizielle Python Package Index (PyPI) zu verwenden.

Bei der Ausführung des Skripts werden die angegeben Manifests durchgegangen und:

- In allen Manifests mit `type:Collection` wird der `service` Attribute hinzugefügt, um die Suche über Collections zu ermöglichen.
- In allen Manifests mit `type:Manifest` werden die `id` und das `label` ausgelesen, und sämtliche, zum Manifest gehörenden Solr-Einträge werden mit diesen Werten ergänzt. Wobei `id` als `manifest_path` und `label` als `manifest_label` im Solr-Index gespeichert werden.


#### Parameter

Bei der Ausführung des Skripts müssen die folgenden Parameter übergeben werden:

| Parameter | Beschreibung | Beispielwert |
| --- | --- | --- |
| `--simulate` | Optional: Wenn definiert, werden keine Anpassungen an den Manifests oder am Solr-Index vorgenommen. Stattdessen werden die Anpassungen im log file gelogged. | `true` |
| `--solr` | URL des Solr-Servers (inkl. Pfad zum Core) | `http://localhost:8983/solr` |
| `--search-base-url` | URL zum Backend-Endpoint zur Suche über Collections. Wird verwendet, um die URL für die `service.id` im Collection-Manifest zu generieren. | `https://viaducdev.cmiag.ch/iiif/iiif/search/collection/` |
| `--prefix-identifier` | Präfix der `id` in den resource manifests. Wird benötigt, um daraus die `source` für die Solr-Abfragen zu generieren.  | `https://viaducdev.cmiag.ch/clientdev/files/manifests/` |

#### Beispiel eines Aufrufs

```bash
# Ausführung des Skripts auf DEV
# Wichtig: PowerShell auf DEV-Server als Administrator ausführen, da Schreibzugriff auf das Verzeichnis E:\localdata\IIIF\files\manifests benötigt wird!
python ./update_script.py E:\localdata\IIIF\files\manifests --solr='http://localhost:8983/solr/iiif2' --search-base-url='https://viaducdev.cmiag.ch/iiif/iiif/search/collection/' --prefix-identifier='https://viaducdev.cmiag.ch/clientdev/files/manifests/'
```


## Testing

Nachdem die Daten indiziert wurden, kann der neue Core getestet werden. Dazu kann die Solr-Admin-Oberfläche aufgerufen werden. Der neue Core sollte dort zur Auswahl stehen.

Typische Abfragen, die durchgeführt werden können, sind:

```
# Erste 10 Einträge ausgeben, die im Feld `manifest_path` einen Wert enthalten
http://localhost:8983/solr/#/iiif/query?q=manifest_path:*&q.op=OR&indent=true

# Erste 10 Einträge ausgeben, die im Feld `manifest_path` keinen Wert enthalten
http://localhost:8983/solr/#/iiif/query?q=-manifest_path:*&q.op=OR&indent=true

# Erste 10 Einträge ausgeben, die im Feld `manifest_label` einen Wert enthalten
http://localhost:8983/solr/#/iiif/query?q=manifest_label:*&q.op=OR&indent=true

# Erste 10 Einträge ausgeben, die im Feld `manifest_label` keinen Wert enthalten
http://localhost:8983/solr/#/iiif/query?q=-manifest_label:*&q.op=OR&indent=true
```


### Troubleshooting

- Lokal konnten nach der Ausführung der Skripte Solr-Einträge gefunden werden, die im Feld `manifest_path` und `manifest_label` noch immer keinen Wert enthalten. Der Grund dafür war, dass die zugehörigen Manifests nicht im Filesystem vorhanden waren.
Sollte dies auch auf dem Server der Fall sein, sollte überprüft werden, ob die Manifests im Filesystem vorhanden sind und ob die Pfade zu den Manifests korrekt sind.
- Lokal konnten zunächst keine Updates am Solr-Index vorgenommen werden. Der Grund dafür war, dass die Pfade zu den hocr-Dateien im Feld `ocr_text` im Solr-Index nicht korrekt waren, bzw. die Dateien nicht im Filesystem vorhanden waren. Nachdem die Pfade korrigiert wurden, konnten die Updates am Solr-Index vorgenommen werden.


## Solr Cores "swappen"

Sollte der neue Core erfolgreich getestet worden sein, kann der neue Core mit dem bestehenden Core "geswapped" werden. Die kann über die Solr-Admin-Oberfläche durchgeführt werden.

Dazu wird der Menüpunkt "Core Admin" aufgerufen. Dort kann der neue Core ausgewählt werden. Anschliessend kann der neue Core mit dem bestehenden Core "geswapped" werden, indem die entsprechende Schaltfläche "swap" genutzt wird und die beiden Cores ausgewählt werden, die getauscht werden sollen.


![](./img/core_swap.png)


## Obsoleter Solr-Core löschen

Wenn die Anpassungen am Core erfolgreich waren, möchte man die Anzahl der Cores wieder reduzieren, indem man den nicht mehr benötigten Core löscht.

Wichtig dabei ist, dass man versteht, dass beim Swappen lediglich die Verweise auf die Cores getauscht werden. Das Zielverzeichnis auf dem Filesystem bleibt jedoch bestehen.

Um sowohl den Namen als auch das Zielverzeichnis des alten Cores zu erhalten, kann man wie folgt vorgehen:

1. In der Solr-Admin-Oberfläche den obsoleten Core über die Schafläche "Unload" entladen.

![](./img/core_unload.png)

2. Den Solr-Server stoppen.

![](./img/stop_solr_service.png)

3. Das Verzeichnis des obsoleten Cores löschen.

```bash
# PowerShell auf DEV-Server als Administrator ausführen
Remove-Item -Recurse -Path "E:\localdata\IIIF\solr\data\iiif"
```

4. Das neue Core-Verzeichnis umbenennen, um den ursprünglichen Namen des alten Cores zu erhalten.

```bash
# PowerShell auf DEV-Server als Administrator ausführen
Rename-Item -Path "E:\localdata\IIIF\solr\data\iiif2" -NewName "iiif"
```

5. Den Solr-Server wieder starten.

![](./img/start_solr_service.png)