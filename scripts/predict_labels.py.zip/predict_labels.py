#!/usr/bin/env python

"""
Script for labeling spans in unseen BAR titles.

"""

import sys
import os
import argparse
import joblib
import string
import statistics
import re

import unicodedata

import pandas as pd

import sklearn
from sklearn.preprocessing import LabelEncoder
from sklearn.feature_extraction import DictVectorizer

from nltk.corpus import stopwords

sys.path.append('lib')
from bar_tools import BARTokenizer, AHVChecker, DateChecker, OffsetParser, BIOGenerator, entity_spans
from bar_tools import FeatureExtractor, get_doc_labels, censoring_labels

#from stopwords import stopwords


class BARModels(object):
    def __init__(self, model_dir):

        self.vectorizer = joblib.load(os.path.join(model_dir, 'vectorizer.joblib'))
        self.models_dict = self.load_models(model_dir)

    def load_models(self, model_dir):

        models_dict = dict()

        for model_fn in os.listdir(model_dir):
            if model_fn == 'vectorizer.joblib' or model_fn.endswith('encoder.joblib') or model_fn.startswith('.'):
                continue

            model_path = os.path.join(model_dir, model_fn)

            if model_fn.endswith('joblib'):
                models_dict[model_fn] = joblib.load(model_path)

        return models_dict

    def get_clf_probsdict_df(self, probs_dictlist, clf_label=''):
        
        le = {0: 'O', 1: 'a', 2: 'd', 3: 'j', 4: 'n', 5: 'p', 6: 'wd'}
        #{0: 'O', 1: 'a', 2: 'd', 3: 'j', 4: 'n', 5: 'p', 6: 'wd'}

        probs_preds_df = pd.DataFrame(probs_dictlist)

        if set(probs_preds_df.columns) == set(list(le.values())):
            probs_preds_df.columns = [f'{c}-{clf_label}' for c in probs_preds_df.columns]
        else:
            probs_preds_df.columns = [f'{le[c]}-{clf_label}' for c in probs_preds_df.columns]
        
        return probs_preds_df
    
    
    def apply_models(self, doc_feat_df, tok_feat_df):

        #preds_df = pd.DataFrame()

        preds_dfs_list = list()

        #vectorizer = DictVectorizer()
        
        feat_matrix = self.vectorizer.transform(tok_feat_df.tok_features)
        feat_matrix = feat_matrix.toarray()

        for model_fn, clf in self.models_dict.items():

            if 'crf' in model_fn.lower():

                #doc_feat_df.to_json('doc_feat_df.json')

                #preds = clf.predict(doc_feat_df.doc_features)
                preds_probas = clf.predict_marginals(doc_feat_df.doc_features)
                #import pdb; pdb.set_trace()

                probs_dictlist = [item for sublist in preds_probas for item in sublist]
                probsdict_df = self.get_clf_probsdict_df(probs_dictlist, clf_label='crf')
                #preds_df[model_fn] = preds_flat
                preds_dfs_list.append(probsdict_df)


            else:
                #label_encoder = joblib.load(os.path.join(model_dir, f"{model_fn.rstrip('.joblib')}.encoder.joblib"))
                #label_encoder = joblib.load(os.path.join(model_dir, "labelencoder.joblib"))
                #preds = clf.predict(feat_matrix)
                preds_probas = clf.predict_proba(feat_matrix)
                
                #preds_df[model_fn] = label_encoder.inverse_transform(preds)
                if 'mlp' in model_fn.lower():
                    probsdict_df = self.get_clf_probsdict_df(preds_probas, clf_label='mlp')
                elif 'svm' in model_fn.lower():
                    probsdict_df = self.get_clf_probsdict_df(preds_probas, clf_label='svm')
                else:
                    raise Exception(f'Error: Model not recognized: {model_path}')
                preds_dfs_list.append(probsdict_df)

        combined_probs = pd.concat(preds_dfs_list, axis=1)
        return combined_probs

class FeatureCollector(object):
    def __init__(self, tokenizer, dictionary_dir, model_dir, context_window=4):
        self.tokenizer = tokenizer
        self.dictionary_dir = dictionary_dir
        self.model_dir = model_dir
        self.ahv_checker = AHVChecker()
        self.ahv_bio_generator = BIOGenerator()
        self.dchecker = DateChecker(
                     sep=['.', ' '],
                     day_numbers=False,
                     month_numbers=False,
                     year_numbers_long=True,
                     year_numbers_short=False,
                     ydm=True,
                     mdy=True)

        # Load common words file
        words_file = os.path.join(self.dictionary_dir, 'deu_news_2010_1M-words-LOWER.tsv')
        common_df = pd.read_csv(words_file, sep='\t', header=None)
        self.common_words = common_df[0]

        ## Load personname list
        personname_file = os.path.join(dictionary_dir, 'ourednik_personnames.csv')
        person_df = pd.read_csv(personname_file, sep='\t')
        self.personnames = person_df.personname

        ## Load firm register list with token probabilities
        creg_file = os.path.join(dictionary_dir, 'CombinedUnigramsFirmnames.tsv')
        creg_df = pd.read_csv(creg_file, sep='\t', dtype='str')
        self.creg_token_prob_dict = pd.Series(creg_df.register_prob.values,index=creg_df.unigram).to_dict()
        self.creg_list = list(creg_df['unigram_lower'])

    def process_hierarchie(self, context_field_data, remove_title=True):
        '''
        Use regex to match words in the archive plan context/hierarchie
        Optionally remove the title from the context (assumes that the last part of the content is the same as the title)
        '''
        if remove_title is True:
            # processing: remove last part which corresponds to the title of the entry
            hier_entry_processed = ' '.join([i.rstrip('\r') for i in context_field_data.split('\n') if i][:-1])
        else:
            hier_entry_processed = ' '.join([i.rstrip('\r') for i in context_field_data.split('\n') if i])
        hier_words = re.findall("[^\W\d_]+", hier_entry_processed, re.UNICODE)
        return(list(set(hier_words)))


    def add_features(self, in_df, dictionary_dir, anon_fields=['titel_fixed'], context_field='context'):

        text_field = anon_fields[0]
        
        # apply spacy preprocessing and tokenization using the bar tokenizer
        spacy_docs = in_df[text_field].apply(lambda x: self.tokenizer.nlp(x))

        # Build the feature overview
        id_df_s = pd.concat([in_df.entry_id, spacy_docs], axis=1)
        id_df_s.columns = ['doc_id', 'spacy_docs']

        ## Add AHV Info
        in_df['matched_ahv'] = in_df.titel_fixed.apply(lambda x: self.ahv_checker.return_ahv_offs(x))
        in_df['ahv_match_dict'] = in_df['matched_ahv'].apply(lambda x: self.ahv_checker.convert_match(x))

        # add hierarchie feature: first 5 characters
        id_df_s['hierarchie'] = in_df[context_field].apply(lambda x: x[:5])

        # add hierarchie feature: words in the hierarchie
        id_df_s['hier_list'] = in_df[context_field].apply(lambda x: '|'.join(self.process_hierarchie(x, remove_title=True)))
        id_df_s['hier_list'] = id_df_s['hier_list'].astype('str')
        
        id_df_s['spacy_features'] = id_df_s['spacy_docs'].apply(lambda x: [(t.text,
                                                                       t.ent_type_,
                                                                       t.ent_iob_,
                                                                       t.pos_,
                                                                       t.tag_,
                                                                       t.lemma_,
                                                                       t.norm_,
                                                                       t.lower_,
                                                                       t.shape_,
                                                                       t.is_alpha,
                                                                       t.is_digit,
                                                                       t.is_punct,
                                                                       t.is_left_punct,
                                                                       t.is_right_punct,
                                                                       t.like_num,
                                                                       t.is_stop) for t in x])
        
        ## EXPAND representation to token level                                                              
        id_df_s_expanded = id_df_s.explode('spacy_features').copy().reset_index(drop=True)

        id_df_s_expanded[['token',
                      'ent_type',
                      'ent_iob',
                      'pos_coarse',
                      'pos_fine',
                      'lemma',
                      'norm',
                      'lower',
                      'shape',
                      'is_alpha',
                      'is_digit',
                      'is_punct',
                      'is_left_punct',
                      'is_right_punct',
                      'like_num',
                      'is_stop'
                     ]] = pd.DataFrame(id_df_s_expanded['spacy_features'].tolist(), index=id_df_s_expanded.index)
        id_df_s_expanded = id_df_s_expanded.drop(['spacy_docs', 'spacy_features'], axis=1)
        
        
        # User datechecker to check if the token looks like a date (or part of a date)
        feat_df = id_df_s_expanded.copy().reset_index(drop=True)


        #ahv_annotations_df = pd.concat((in_df['titel_fixed'], ahv_match_dict), axis=1)
        ahv_annotations = in_df[[text_field, 'ahv_match_dict']].apply(lambda x: {'text':x[0], 'ents':x[1]}, axis=1)
        #ahv_annotations = ahv_annotations.apply(lambda x: {'text':x[0], 'ents':x[1]}, axis=1)
        spacy_docs_ahv = ahv_annotations.apply(lambda x: entity_spans(x, self.tokenizer.nlp))
        ## Generate BIO format

        id_df_ahv = pd.concat([spacy_docs_ahv.reset_index(drop=True), in_df['entry_id'].astype('str').reset_index(drop=True)], axis=1)  ## Correct format?

        id_df_ahv.columns = ['annotation', 'doc_id']
        id_df_ahv.apply(lambda x: self.ahv_bio_generator.add_entry(x[0], identifier=x[1], identifier_name='doc_id'), axis=1)
        ahv_bio_df = self.ahv_bio_generator.df.reset_index(drop=True)

        feat_df['ahvcheck'] = ahv_bio_df['annotation'].apply(lambda x: True if x == 'a' else False)

        feat_df['datecheck'] = feat_df.token.apply(lambda x: self.dchecker.check_date(x))
        
        
        # Add dictionary features

        ## Common words feature
        feat_df['common_words'] = feat_df.lower.isin(self.common_words)
        
        # compare lower-cased version
        feat_df['in_personnames'] = feat_df.lower.isin(self.personnames)
        
        ## Load placenames list
        placenames_file = os.path.join(dictionary_dir, 'schweizer_ortsnamen-wikipedia.csv')
        placenames_df = pd.read_csv(placenames_file)
        places = placenames_df['Ortschaftsname']
        places_split = places.apply(lambda x: x.split())

        # compare parts of placenames if they are not in the stopwords list
        stop_words = stopwords.words('german')
        places_nostops = places_split.apply(lambda x: [i for i in x if i not in stop_words])
        places_unique = pd.Series(places_nostops.explode().unique())
        places_unique_lower = places_unique.str.lower().str.strip(string.punctuation).unique()
        places_series = pd.Series(places_unique_lower)
        feat_df['in_swissplaces'] = feat_df.lower.isin(places_series)

        # Check if token is in registry
        feat_df['in_register'] = feat_df.token.str.lower().isin(self.creg_list)
        feat_df['register_prob'] = feat_df.token.apply(lambda x: self.creg_token_prob_dict.get(x,  0.0))
        
        return feat_df


class BarAnonymizer(object):
    def __init__(self, dictionary_dir, model_dir, context_window=4, j_thresh=0.1, n_thresh=0.17):
        self.dictionary_dir = dictionary_dir
        self.model_dir = model_dir
        self.context_window = context_window
        self.j_thresh = j_thresh
        self.n_thresh = n_thresh
        self.labels = ['j', 'n', 'p', 'd', 'O', 'wd', 'a']
        self.black_labels = ['n', 'd', 'j', 'wd', 'a']
        self.weight_dict = {'crf': 2, 'svm': 1, 'mlp': 1}
        self.tokenizer = BARTokenizer()
        self.feature_collector = FeatureCollector(self.tokenizer, self.dictionary_dir, self.model_dir, context_window=self.context_window)
        self.models = BARModels(model_dir)

    def blackout_format(self, labeled_df, black_char=chr(9608)):

        labeled_df['labeled_tokens'] = labeled_df[['token', 'blackout_label']].apply(lambda x: black_char * 3 if str(x[1]) == 'True' else x[0], axis=1)

        #import pdb; pdb.set_trace()

        pred_df_entries = labeled_df.groupby('doc_id').agg(lambda x: ' '.join([str(i) for i in list(x)])).reset_index()
        return pred_df_entries


    def labels_format(self, labeled_df):
        labeled_df['labeled_tokens'] = labeled_df[['token', 'ensemble_label']].apply(lambda x: f"<anonym type='{x[1]}'>{x[0]}</anonym>" if x[1] in self.black_labels else x[0], axis=1)
        pred_df_entries = labeled_df.groupby('doc_id').agg(lambda x: ' '.join([str(i) for i in list(x)])).reset_index()
        return pred_df_entries

    @staticmethod
    def find_label_weighted_meanthresh(prob_dict, n_thresh=0.2, j_thresh=0.15, weight_dict={'crf':2, 'svm':1, 'mlp':1}):
      
        if sum([prob_dict[n]*weight_dict[n[-3:]] for n in [k for k in prob_dict.keys() if k.startswith('n-')]])/sum(weight_dict.values()) > n_thresh :
            return 'n'
        if sum([prob_dict[j]*weight_dict[j[-3:]] for j in [k for k in prob_dict.keys() if k.startswith('j-')]])/sum(weight_dict.values()) > j_thresh :
            return 'j'
        else:
            max_key = max(prob_dict, key=prob_dict.get)
            return max_key[:2].rstrip('-')

    def anonymize_df(self, in_df, anon_field='TITEL', id_field='VE_ID', anon_style='blacked'):
        '''Input: a pandas dataframe.'''

        # normalize non-breaking whitespaces (e.g. '\xa0')
        in_df = in_df.copy()
        in_df['titel_fixed'] = in_df[anon_field].astype('str').apply(lambda x: unicodedata.normalize("NFKD", x))
        in_df['doc_id'] = in_df[id_field]
    
        feat_df = self.feature_collector.add_features(in_df, self.dictionary_dir)

        feature_extractor = FeatureExtractor(feat_df, context_window=self.context_window)
        doc_ids = pd.Series(feat_df['doc_id'].unique())
        doc_features = doc_ids.apply(lambda x: feature_extractor.doc2features(x))  # series of dictionaries

        doc_feat_df = pd.concat((doc_features, doc_ids), axis=1)
        doc_feat_df.columns = ['doc_features', 'doc_id']

        # convert to token level
        tok_feat_df = doc_feat_df.explode('doc_features')
        tok_feat_df = tok_feat_df.reset_index(drop=True).reset_index()
        tok_feat_df.columns = ['td-idx', 'tok_features', 'doc_id']

        combined_probs = self.models.apply_models(doc_feat_df, tok_feat_df)
        
        prob_dicts = combined_probs[[c for c in combined_probs.columns if any([c.startswith(f'{i}-') for i in self.labels])]].apply(lambda x: x.to_dict(), axis=1)

        weighted_meanthresh = prob_dicts.apply(lambda x: self.find_label_weighted_meanthresh(x, n_thresh=self.n_thresh, j_thresh=self.j_thresh, weight_dict=self.weight_dict))


        labeled_df = tok_feat_df[['td-idx', 'doc_id']]
        labeled_df['token'] = feat_df['token']
        labeled_df['weighted_meanthresh'] = weighted_meanthresh
        #labeled_df = pd.concat([labeled_df, weighted_meanthresh], axis=1)

        ## Re-labeling according to rules
        relabeler = Relabeler()
        preds = relabeler.relabel_all(labeled_df, prob_dicts)

        blackout_labels = preds.apply(lambda x: x in self.black_labels)
        labeled_df['blackout_label'] = blackout_labels
        labeled_df.columns = ['td-idx', 'doc_id', 'token', 'ensemble_label', 'blackout_label']

        if anon_style == 'blacked':
            blackout_df = self.blackout_format(labeled_df, black_char=chr(9608))
            blackout_df = blackout_df[['doc_id', 'token', 'blackout_label', 'labeled_tokens']].copy()
            return blackout_df
        elif anon_style == 'tags':
            labels_df = self.labels_format(labeled_df)
            return labels_df
        else:
            raise Exception(f'Unknown style for anonymization: {anon_style}. Valid options for anon_style are blacked or tags.')


    def json2df(self, json_data):
        column_names = ['VE_ID', 'HIERARCHIE', 'SIGNATUR', 'TITEL', 'DARIN', 'ZUSATZKOMPONENTE', 'LAND', 'ENTSTEHUNGSZEITRAUM', 'Annot_Sprache', 'Annot_Bemmerkung', 'Liste', 'QS-Korrektur']
        if isinstance(json_data, list):
            json_data_df = pd.DataFrame(json_data)
            json_data_split = json_data_df.text.apply(lambda x: x.split('\t'))  # TODO: verify if number of fields corresponds to number of columns in column_names
            lengths = json_data_split.apply(lambda x: len(x)).unique()
            if len(lengths) == 1 and lengths[0] != len(column_names):
                raise Exception(f'Wrong field length of input. Expected: {len(column_names)}, received {lengths}.')
            in_df = pd.DataFrame(json_data_split.to_list(), columns=column_names)
        elif isinstance(json_data, dict):
            json_fields = json_data['text'].split('\t')
            in_df = pd.DataFrame(json_fields).T
            in_df.columns = column_names
        else:
            raise Exception('Wrong data format in Json input.')
        return in_df

    def process_file_input(self, file_path):
        # process input formats
        if file_path.endswith('.tsv'):
            in_df = pd.read_csv(file_path, sep='\t', dtype='str')
        elif file_path.endswith('.xlsx'):
            in_df = pd.read_excel(file_path, dtype='str')
        elif file_path.endswith('.json'):
            with open(file_path, 'r') as infile:
                json_data = json.loads(infile)
                # TODO: process json input as file!

        else:
            raise Exception('Input file format not recognized.')

        return in_df

    def anonymize_file_input(self, in_path):
        in_df = self.process_file_input(in_path)
        blackout_df = self.blackout_df(in_df)
        return blackout_df


    def json2df_newspec(self, json_data):
        if isinstance(json_data, dict):
            json_values = json_data['values']
            json_df = pd.DataFrame(json_values, index=[0])
            json_df['context'] = json_data['context']
            json_df['anon_style'] = json_data['options']['style']
            json_df['anon_fields'] = '|'.join(list(json_data['values'].keys()))
            json_df['entry_id'] = list(range(json_df.shape[0]))

        else:
            raise Exception('Wrong data format in Json input.')
        return json_df

    def anonymize_json(self, input):
        in_df = self.json2df_newspec(input)
        anonfields_df = pd.DataFrame()
        anon_style = in_df['anon_style'][0]
        for anon_field_name in in_df['anon_fields'][0].split('|'):
            blackout_df = self.anonymize_df(in_df, anon_field=anon_field_name, id_field='entry_id', anon_style=anon_style)

            anonfields_df[anon_field_name] = blackout_df['labeled_tokens']

        if anonfields_df.shape[0] != 1:
            raise Exception(f'Json output has unusual shape: {anonfields_df.shape}')
        else:
            #json_out = {"anonymizedValues": anonfields_df.iloc[0].to_dict()}
            anonfields_df_normalized = anonfields_df.apply(lambda x: x.str.normalize('NFKC'), axis=1)
            json_out = anonfields_df_normalized.iloc[0].to_dict()
            return json_out

    def blacken(self, input):
        '''
        Input: one dictionary or a list of dictionaries.
        Output: an anonymized string or list of anonymized strings depending on type of input.
        '''
        in_df = self.json2df_newspec(input)
        blackout_df = self.anonymize_df(in_df, anon_style='blacked')
        blackout_list = blackout_df.labeled_tokens.tolist()
        if len(blackout_list) == 1:
            return blackout_list[0]
        return blackout_list

    def get_labels(self, input):
        in_df = self.json2df_newspec(input)
        anonlabels_df = self.anonymize_df(in_df, anon_style='tags')
       
        anonlabels_list = anonlabels_df.labeled_tokens.tolist()
        if len(anonlabels_list) == 1:
            return anonlabels_list[0]
        return anonlabels_list


def run_anonymize(args=None):

    anonymizer = BarAnonymizer(args.dictionary_dir, args.model_dir)

    blackout_df = anonymizer.anonymize_file_input(args.in_path)

    blackout_df.to_csv(args.out_path, sep='\t', header=True, index=None)


class Relabeler(object):
    '''Relabeling according to rules'''
    def __init__(self):
        self.pers_titles = ['Dr.', 'Prof.', 'Herr', 'Frau', 'Hr.', 'Fr.', 'Mr.', 'Ms.', 'Mme.', 'Familie', 'Famille', 'Famiglia']
        self.numtok_after_titles = 3
        self.n_thresh_after_titles = 0.001

        self.n_thresh_no_nj = 0.01
        self.j_thresh_no_nj = 0.01

    def _no_nj(self, label_list):
        if not set(label_list).intersection(['j', 'n']):
            return True
        return False

    def relabel_after_title(self, labels_df, prob_dicts):
        # detect tokens which are titles and get their indices
        is_title = labels_df['token'].isin(self.pers_titles)
        title_indices = is_title[is_title == True].index
        after_title_indices = pd.Series(title_indices).apply(lambda x: [x+i for i in range(1,self.numtok_after_titles+1)]).explode().unique()

        after_title_indices = set(labels_df.index).intersection(after_title_indices)

        after_title_indices = pd.Index(after_title_indices)

        after_title_relabels = prob_dicts[after_title_indices].apply(lambda x: BarAnonymizer.find_label_weighted_meanthresh(x, n_thresh=self.n_thresh_after_titles))

        after_title_relabels = after_title_relabels.reindex(labels_df.index)

        return after_title_relabels

    def relabel_no_nj(self, labels_df, prob_dicts):
        grouped_labels = labels_df.groupby('doc_id').agg(list).reset_index()
        no_nj = grouped_labels['weighted_meanthresh'].apply(lambda x: self._no_nj(x))
        no_nj_veids = grouped_labels[no_nj]['doc_id'].to_list()

        no_nj_relabel = labels_df['doc_id'].apply(lambda x: x in no_nj_veids)

        no_nj_relabeled = prob_dicts[no_nj_relabel].apply(lambda x: BarAnonymizer.find_label_weighted_meanthresh(x, n_thresh=self.n_thresh_no_nj, j_thresh=self.j_thresh_no_nj))

        no_nj_relabeled = no_nj_relabeled.reindex(labels_df.index)

        return no_nj_relabeled

    def relabel_all(self, labels_df, prob_dicts):
        relabels_after_title = self.relabel_after_title(labels_df, prob_dicts)
        relabels_no_nj = self.relabel_no_nj(labels_df, prob_dicts)

        relabeled_joined = relabels_after_title.fillna(relabels_no_nj).fillna(labels_df['weighted_meanthresh'])

        return relabeled_joined

    
def main():
    """
    Invoke this module as a script
    """

    description = "...."
    parser = argparse.ArgumentParser(description=description)
    parser.add_argument('-l', '--logfile', dest='logfilename',
                        help='write log to FILE', metavar='FILE')
    parser.add_argument('-q', '--quiet',
                        action='store_true', dest='quiet', default=False,
                        help='do not print status messages to stderr')
    parser.add_argument('-d', '--debug',
                        action='store_true', dest='debug', default=False,
                        help='print debug information')
    
    parser.add_argument('--in_path', metavar='in_path', type=str, required=True,
                        help='Path to tsv or excel file containing entries to be labeled.')
    parser.add_argument('--out_path', metavar='out_path', type=str, required=True,
                        help='Path to output file (tsv with labels included).')
    parser.add_argument('--dictionary_dir', metavar='dictionary_dir', type=str, required=True,
                        help='Path to directory containing dictionaries.')
    parser.add_argument('--model_dir', metavar='model_dir', type=str, required=True,
                        help='Path to directory containing the machine learning models.')
    
    
    
    args = parser.parse_args()
    print('Args:', args)
    
    run_anonymize(args=args)

    sys.exit(0)  # Everything went ok!
    
    
if __name__ == '__main__':
    main()
